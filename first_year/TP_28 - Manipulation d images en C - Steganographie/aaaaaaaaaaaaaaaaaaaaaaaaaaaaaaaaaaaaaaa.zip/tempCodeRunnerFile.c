
    printf("%d", img->haut);